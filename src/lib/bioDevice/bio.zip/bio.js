import axios from "axios";

var readyDevices = [];


var header = {
  "Content-Type": "text/plain",
};
var infoHeader = {
  "Content-Type": "text/xml",
};

// port discovery function  invoke RD services API
export function discoverPort() {
  for (let i = 11100; i <= 11120; i++) {
    let url = "http://localhost:" + i;
    console.log(i);

    rdservice(url);
  }
  return readyDevices
}

async function rdservice(url) {
  var result = await apiCaller("RDSERVICE", url, header, "xml");

  if (result == null) {
    return "na";
  }

  let xmlDat = xmlToString(result.data);
  if (xmlDat) {
    let deviceStatus = xmlDat
      .getElementsByTagName("RDService")[0]
      .getAttribute("status");
    let infoMsg = xmlDat
      .getElementsByTagName("RDService")[0]
      .getAttribute("info");
    let capturePath = xmlDat
      .getElementsByTagName("Interface")[0]
      .getAttribute("path");
    let infoPath = xmlDat
      .getElementsByTagName("Interface")[1]
      .getAttribute("path");

    if (deviceStatus === "READY") {
      readyDevices.push({
        url: url,
        deviceStatus: deviceStatus,
        infoMsg: infoMsg,
        capturePath: capturePath,
        infoPath: infoPath,
      });
      console.log("rd --- " + JSON.stringify(readyDevices));
      
    }
    if (readyDevices.length === 0) {
      console.log("Unable to detect any registered bio-metric device!");
    } else if (readyDevices.length > 1) {
      console.log("Multiple devices detected! Please use only one device.");
    }
  }
}


//  axios invoker
// pass url, method and payload , returns res object
async function apiCaller(method, url, header, data, responseType) {
  return await axios({
    method: method,
    url: url,
    headers: header,
    data: data,
    responseType: responseType,
  })
    .then(function (response) {
      if (!response) {
        return null;
      } else {
        // console.log("response --- " + JSON.stringify(response));
        return response;
      }
    })
    .catch(function (error) {
      //   errCode = "";
      return null;
    });
}

// xml parser method - inputs xml and returns string
function xmlToString(res) {
  if (res === null || res === undefined) {
    return null;
  }
  var parser = new DOMParser();
  var xmlDat = parser.parseFromString(res, "text/xml");
  // console.log("xml to " + xmlDat)
  return xmlDat;
}

